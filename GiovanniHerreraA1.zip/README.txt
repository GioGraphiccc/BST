Assignment #1 Instructions: Sorting with Binary Search Tree
Author: Giovanni Herrera
PID: 6165247
This is my introduction to a binary Search Tree.

./output [-c] [-l] [-o output_file_name] [input_file_name]
